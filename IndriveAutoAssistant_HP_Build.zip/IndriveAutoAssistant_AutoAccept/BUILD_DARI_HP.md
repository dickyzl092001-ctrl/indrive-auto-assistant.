# Membuat APK hanya dari HP

1. Buat akun atau masuk ke GitHub melalui browser HP.
2. Buat repository baru, misalnya `indrive-auto-assistant`. Pilih Public atau Private sesuai kenyamanan.
3. Ekstrak ZIP project di HP menggunakan aplikasi pengelola arsip.
4. Unggah seluruh isi folder project ke repository GitHub, termasuk folder `.github/workflows`.
   Pastikan file `build-apk.yml` berada di `.github/workflows/build-apk.yml`.
5. Buka tab **Actions** di repository. Jika diminta, izinkan workflow berjalan.
6. Jalankan workflow **Build Android APK** melalui tombol **Run workflow**, atau tunggu build otomatis setelah push ke branch `main`.
7. Setelah selesai, buka hasil run yang berstatus sukses, gulir ke **Artifacts**, lalu unduh `inDrive-AutoAssistant-debug`.
8. Ekstrak file artifact dan instal `app-debug.apk` pada HP.

Catatan:
- Ini hanya cara membangun project; bukan jaminan APK akan bekerja dengan semua versi inDrive.
- GitHub Actions membutuhkan akun GitHub dan koneksi internet.
- Simpan repository sebagai Private jika tidak ingin kode project terlihat publik.
- APK debug bukan aplikasi Play Store. Android mungkin meminta izin instalasi dari sumber tersebut.
- Uji hanya saat kendaraan berhenti. Auto Accept dapat menerima order yang tidak diinginkan.
