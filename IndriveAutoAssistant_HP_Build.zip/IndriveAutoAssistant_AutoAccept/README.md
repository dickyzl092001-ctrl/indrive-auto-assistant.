# inDrive Auto Assistant — Auto Accept prototype

Contoh project Android/Kotlin untuk:
- Mendeteksi tampilan kartu permintaan yang memuat teks “Terima dengan harga”.
- Membacakan teks order melalui Text-to-Speech Bahasa Indonesia.
- Jika sakelar Auto Accept diaktifkan, mencoba menjalankan Accessibility ACTION_CLICK pada tombol/parent yang cocok.

## Penting: bukan APK siap instal
Project ini perlu dibuka dan dibangun di Android Studio. Belum diuji pada perangkat Realme RMX5020 atau versi aplikasi inDrive milik pengguna.

## Batasan teknis
- Android Accessibility hanya dapat menekan kontrol jika inDrive mengekspos node teks/tombol yang dapat diakses. Jika tombol digambar sebagai elemen khusus atau tidak diekspos, klik tidak akan berhasil.
- Nama package inDrive dapat berbeda. Service saat ini hanya bekerja bila nama package mengandung `indriver` atau `indrive`; mungkin perlu disesuaikan setelah memeriksa package aktual.
- Debounce 45 detik menggunakan fingerprint teks untuk mengurangi klik berulang, tetapi tidak menjamin order unik selalu dikenali sempurna.
- Tidak menggunakan koordinat layar tetap karena posisi tombol dapat berubah menurut ukuran layar, orientasi, dan versi aplikasi.
- Penggunaan auto-accept dapat menyebabkan order yang tidak diinginkan diterima dan mungkin tidak sesuai ketentuan inDrive. Pastikan kamu memahami risikonya.
- Jangan mengaktifkan atau mengubah pengaturan saat mengemudi. Uji hanya ketika kendaraan berhenti dan kamu siap mengambil order.

## Build
1. Buka folder project di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build APK(s).
4. Instal APK pada HP sendiri.
5. Buka aplikasi dan aktifkan layanan “inDrive Auto Accept” di Pengaturan Aksesibilitas.
6. Kembali ke aplikasi dan uji dengan Auto Accept dalam keadaan OFF terlebih dahulu.
7. Jika pembacaan berhasil, aktifkan Auto Accept hanya untuk pengujian terkendali saat kendaraan berhenti.

## Privasi
Layanan aksesibilitas dapat membaca teks jendela aktif. Prototipe ini tidak mengirim data ke server dan tidak menyimpan isi order secara permanen.
