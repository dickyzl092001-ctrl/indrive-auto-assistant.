package com.example.indriveassistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("assistant_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "inDrive Auto Assistant"
            textSize = 24f
        }
        val subtitle = TextView(this).apply {
            text = "\nAuto Accept + Voice Alert"
            textSize = 18f
        }
        val warning = TextView(this).apply {
            text = "\nPERHATIAN: Jika Auto Accept aktif, aplikasi akan mencoba menekan tombol " +
                "\"Terima dengan harga\" secara otomatis setiap kali tombol terdeteksi. " +
                "Order yang tidak diinginkan juga dapat diterima. Gunakan hanya saat kendaraan " +
                "berhenti dan kamu siap mengambil order. Fitur dapat tidak bekerja jika inDrive " +
                "tidak mengekspos tombol melalui Accessibility."
            textSize = 14f
        }
        val autoSwitch = Switch(this).apply {
            text = "Auto Accept (terima otomatis)"
            textSize = 17f
            isChecked = prefs.getBoolean("auto_accept", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_accept", checked).apply()
            }
        }
        val voiceSwitch = Switch(this).apply {
            text = "Bacakan order dengan suara"
            textSize = 17f
            isChecked = prefs.getBoolean("voice_alert", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("voice_alert", checked).apply()
            }
        }
        val accessibilityButton = Button(this).apply {
            text = "Buka pengaturan Aksesibilitas"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val layoutInfo = TextView(this).apply {
            text = "\nCara pakai:\n" +
                "1. Aktifkan layanan aksesibilitas untuk inDrive Auto Accept.\n" +
                "2. Kembali ke aplikasi ini.\n" +
                "3. Aktifkan Auto Accept hanya saat kamu siap menerima order.\n" +
                "4. Buka inDrive. Uji dahulu ketika kendaraan berhenti."
            textSize = 15f
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(autoSwitch)
        layout.addView(voiceSwitch)
        layout.addView(warning)
        layout.addView(accessibilityButton)
        layout.addView(layoutInfo)
        setContentView(layout)
    }
}
