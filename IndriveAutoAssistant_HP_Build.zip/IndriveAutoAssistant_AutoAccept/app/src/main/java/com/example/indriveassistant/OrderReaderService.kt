package com.example.indriveassistant

import android.accessibilityservice.AccessibilityService
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class OrderReaderService : AccessibilityService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastAcceptedFingerprint = ""
    private var lastAcceptedAt = 0L
    private var lastSpokenFingerprint = ""
    private var lastSpokenAt = 0L

    private val prefs by lazy { getSharedPreferences("assistant_settings", MODE_PRIVATE) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("id", "ID"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString()?.lowercase(Locale.ROOT) ?: return
        // Jangan bertindak pada aplikasi lain. Nama paket bisa berbeda antar versi/region.
        if (!pkg.contains("indriver") && !pkg.contains("indrive")) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectText(root, texts)
        val allText = texts.distinct().joinToString(". ")
        val normalized = allText.lowercase(Locale.ROOT)

        val hasAcceptButtonText = normalized.contains("terima dengan harga")
        val looksLikeRequest = hasAcceptButtonText &&
            (normalized.contains("permintaan transportasi") ||
             normalized.contains("harga wajar") ||
             normalized.contains("km"))

        if (!looksLikeRequest) return

        val fingerprint = allText.hashCode().toString()
        val now = System.currentTimeMillis()

        if (prefs.getBoolean("voice_alert", true) && ttsReady &&
            (fingerprint != lastSpokenFingerprint || now - lastSpokenAt > 30_000L)) {
            lastSpokenFingerprint = fingerprint
            lastSpokenAt = now
            val spoken = allText.replace(Regex("\\s+"), " ").take(550)
            tts?.speak("Ada permintaan inDrive. $spoken", TextToSpeech.QUEUE_FLUSH, null, "order_notice")
        }

        if (!prefs.getBoolean("auto_accept", false)) return
        if (fingerprint == lastAcceptedFingerprint && now - lastAcceptedAt < 45_000L) return

        val clicked = clickAcceptControl(root)
        if (clicked) {
            lastAcceptedFingerprint = fingerprint
            lastAcceptedAt = now
            if (ttsReady) {
                tts?.speak("Mencoba menerima order.", TextToSpeech.QUEUE_ADD, null, "accept_notice")
            }
        }
    }

    private fun clickAcceptControl(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false

        val nodeText = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val nodeDesc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val matches = nodeText.contains("terima dengan harga") ||
                      nodeDesc.contains("terima dengan harga")

        if (matches) {
            var candidate: AccessibilityNodeInfo? = node
            // Tombol teks kadang berada di dalam parent yang clickable.
            while (candidate != null) {
                if (candidate.isEnabled && candidate.isClickable) {
                    return candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                candidate = candidate.parent
            }
        }

        for (i in 0 until node.childCount) {
            if (clickAcceptControl(node.getChild(i))) return true
        }
        return false
    }

    private fun collectText(node: AccessibilityNodeInfo?, output: MutableList<String>) {
        if (node == null) return
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { output.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { output.add(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), output)
    }

    override fun onInterrupt() {
        tts?.stop()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
