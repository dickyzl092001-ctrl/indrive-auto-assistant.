plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.indriveassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.indriveassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
